﻿using AngularJSMVC_3.CodeLayers.RepositoryLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace AngularJSMVC_3.CodeLayers.ServiceLayer
{
    public class User : IUserService
    {
        public int id { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string email { get; set; }
        public DateTime dob { get; set; }
        public bool active { get; set; }

        IUserRepository _userRepo;



        public void Add(User u)
        {
            throw new NotImplementedException();
        }

        public void Update(User i)
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }

        public List<User> RetrieveAll()
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}