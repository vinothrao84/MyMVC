﻿using AngularJSMVC_3.CodeLayers.ServiceLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AngularJSMVC_3.CodeLayers.ServiceLayer
{
    public interface IMainService : IDisposable
    {

    }
}
