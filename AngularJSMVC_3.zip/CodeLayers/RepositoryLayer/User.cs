﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using AngularJSMVC_3.Models;

namespace AngularJSMVC_3.CodeLayers.RepositoryLayer
{
    public class User : IUserRepository, IMainRepository
    {
        DataMgmtEntities db = new DataMgmtEntities();

        public void Add(User u)
        {
            throw new NotImplementedException();
        }

        public void Delete(int id)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public List<User> RetrieveAll()
        {
            throw new NotImplementedException();
        }

        public void Update(User i)
        {
            throw new NotImplementedException();
        }
    }
}