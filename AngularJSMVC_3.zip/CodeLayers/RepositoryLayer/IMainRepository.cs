﻿using AngularJSMVC_3.CodeLayers.ServiceLayer;
using AngularJSMVC_3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AngularJSMVC_3.CodeLayers.RepositoryLayer
{
    public interface IMainRepository : IDisposable
    {
        
    }
}
