﻿using AngularJSMVC_3.CodeLayers.ServiceLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AngularJSMVC_3.CodeLayers.RepositoryLayer
{
    public interface IInventoryRepository : IMainRepository, IDisposable
    {
        string MyInventory(int id);
    }
}
