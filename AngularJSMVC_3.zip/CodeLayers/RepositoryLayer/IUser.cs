﻿using AngularJSMVC_3.CodeLayers.ServiceLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AngularJSMVC_3.CodeLayers.RepositoryLayer
{
    public interface IUserRepository : IDisposable
    {
        void Add(User u);
        void Update(User i);
        void Delete(int id);
        List<User> RetrieveAll();
    }
}
